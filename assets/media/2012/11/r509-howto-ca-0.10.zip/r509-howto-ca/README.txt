Building a CA (r509 Howto)
http://langui.sh/2012/11/02/building-a-ca-r509-howto/

This zip contains the rackup files, basic config yamls, and empty serial/revoke list files you need for the tutorial. To get going you'll need to run the following command:

gem install r509 r509-ocsp-responder r509-ca-http r509-middleware-validity r509-middleware-certwriter

You'll also need to install redis and start up the redis-server (see the blog post)

Once you've done this you can run through the blog post to:

- set up the directory where you want the certs written (and point to it in config.yaml)
- generate your root certificate (and point to it from config.yaml and ocsp/config.yaml)

And get your CA up and running!
