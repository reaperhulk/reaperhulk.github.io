This needs to be populated with the standard WP readme info

Howto create a new cdn class

Create a directory in cdn_classes named whatever the shortname will be (need to define shortname)
Create a file named loader.php inside with the following basic structure (member functions and class names are required).  load_js_files must return the baseURI for the files as well as an array of files it loaded.
class cdn_loader {
	public function load_js_files($filestoload) {
		return array($baseuri,$loadedfiles);
	}
	
	public function remove_files() {
		return true;
	}
}