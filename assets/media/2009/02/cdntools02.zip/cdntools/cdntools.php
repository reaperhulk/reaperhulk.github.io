<?php
/*
Plugin Name: CDN Tools
Plugin URI: http://swearingscience.com/cdntools
Description: Tools for the CDN user.
Author: Paul Kehrer
Version: 0.2
Author URI: http://swearingscience.com/
*/ 

/*  Copyright 2009  Paul Kehrer

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

//ini_set('display_errors',1);

if ( ! defined( 'WP_CONTENT_URL' ) )
      define( 'WP_CONTENT_URL', get_option( 'siteurl' ) . '/wp-content' );
if ( ! defined( 'WP_CONTENT_DIR' ) )
      define( 'WP_CONTENT_DIR', ABSPATH . 'wp-content' );
if ( ! defined( 'WP_PLUGIN_URL' ) )
      define( 'WP_PLUGIN_URL', WP_CONTENT_URL. '/plugins' );
if ( ! defined( 'WP_PLUGIN_DIR' ) )
      define( 'WP_PLUGIN_DIR', WP_CONTENT_DIR . '/plugins' );

$cdntools = new cdntools();
add_action('plugins_loaded', array($cdntools, 'cdnify_wp_default_scripts'));

class cdntools	{
	private $wp_scripts = null;
	private $gscripts = null;
	private $cdn_options = null;
	private $cdntools_googleajax = null;
	private $cdntools_primarycdn = null;
	private $cdntools_baseuri = null;
	private $cdntools_loadedfiles = null;
	private $cdntools_authname = null;
	private $cdntools_authkey = null;
	private $cdntools_ignoreadmin = null;
	
	function __construct(){
		add_action("admin_menu", array($this,"add_admin_pages"));
		/*
		set up the scripts we can fetch from google's cdn.  while scriptaculous and 
		jqueryui are available, they aren't modular so let's ignore them.
		*/
		$this->gscripts = array(
			'dojo' => 'dojo.xd',
			'jquery' => 'jquery.min',
			'mootools' => 'mootools-yui-compressed',
			'prototype' => 'prototype'
		);
		
		//obtain our options
		$this->cdntools_googleajax = get_option('cdntools_googleajax');
		$this->cdntools_primarycdn = get_option('cdntools_primarycdn');
		$this->cdntools_baseuri = get_option('cdntools_baseuri');
		$this->cdntools_loadedfiles = unserialize(get_option('cdntools_loadedfiles')); //if nothing is loaded this will trigger an E_NOTICE
		$this->cdntools_authname = get_option('cdntools_authname');
		$this->cdntools_authkey = get_option('cdntools_authkey');
		$this->cdntools_ignoreadmin = get_option('cdntools_ignoreadmin');
		switch($this->cdntools_primarycdn) {
			case "cloudfiles":
				require(WP_PLUGIN_DIR."/cdntools/cdn_classes/cloudfiles.php");
			break;
			case "amazon":
				//amazon libs here
			break;
			default:
		}
	}
	
	/* 
	this is the current core of functionality.  we loop through registered scripts and 
	modify their URLs to point at the CDN
	*/
	function cdnify_wp_default_scripts() {
		global $wp_scripts;
		if($this->cdntools_primarycdn == "cloudfiles" && $this->cdntools_baseuri != null && is_array($this->cdntools_loadedfiles)) {
			foreach($wp_scripts->registered as $scriptobj) {
				if(in_array($scriptobj->handle,$this->cdntools_loadedfiles)) {
					//cloudfiles does not support https so http only here
					$scriptobj->src = $this->cdntools_baseuri.'/'.$scriptobj->handle.".js";
				}
			}
		}
		//check to see if we need to use googleajax CDN.  google overrides previous cdn'd scripts
		if($this->cdntools_googleajax) {
			$this->google_wp_default_scripts();
		}
	}
	
	function google_wp_default_scripts() {
		global $wp_scripts;
		foreach($wp_scripts->registered as $object) {
			if(array_key_exists($object->handle,$this->gscripts)) {
				$libname = $object->handle;
				$jsname = $this->gscripts[$libname];
				$ver = $object->ver;
				$transport = (is_ssl())?'https':'http'; //make it ssl if the site is ssl.
				$object->src = "$transport://ajax.googleapis.com/ajax/libs/$libname/$ver/$jsname.js";			
			}
		}
		//google's jquery does not turn on noConflict mode so we need to add a script to do that.
		//wp_enqueue_script('jquery-noconflict',)
	}
	
	function cloudfiles_cdn_load() {
		global $wp_scripts;
		$auth = new CF_Authentication($this->cdntools_authname,$this->cdntools_authkey);
		try {
			$auth->authenticate();
		}
		catch(AuthenticationException $e) {
			//for some reason this returns two error msgs.  one is echo'd even without the below echo
			echo $e->getMessage();
			return false;
		}
		
		$conn = new CF_Connection($auth);
		$wp_cdntools = $conn->create_container("wp_cdntools");
		
		$loadedfiles = array();
		foreach($wp_scripts->registered as $scriptobj) {
			if(strpos($scriptobj->src,"http") === false && strlen($scriptobj->src) > 0) {
				//don't touch URL pathed scripts for now.  probably added by plugins
				if($this->cdntools_ignoreadmin == false || ($this->cdntools_ignoreadmin == 1 && strpos($scriptobj->src,"wp-admin") === false)) {
					//don't load admin scripts into the CDN if the pref is set
					$object = $wp_cdntools->create_object($scriptobj->handle.'.js');
					$object->load_from_filename(ABSPATH.$scriptobj->src);
					$loadedfiles[] = $scriptobj->handle;
				}
			}
		}
		$cdntools_baseuri = $wp_cdntools->make_public(86400); //ttl of one day
		update_option('cdntools_baseuri',$cdntools_baseuri);
		update_option('cdntools_loadedfiles',serialize($loadedfiles));
	}
	
	function cloudfiles_cdn_remove() {
		$auth = new CF_Authentication($this->cdntools_authname,$this->cdntools_authkey);
		try {
			$auth->authenticate();
		}
		catch(AuthenticationException $e) {
			//for some reason this returns two error msgs.  one is echo'd even without the below echo
			echo $e->getMessage();
			return false;
		}
		$conn = new CF_Connection($auth);
		$wp_cdntools = $conn->create_container("wp_cdntools");
		
		//check for objects and remove them all if they exist
		$existing_objects = $wp_cdntools->list_objects();
		if(is_array($existing_objects)) {
			foreach($existing_objects as $name) {
				$wp_cdntools->delete_object($name);
			}
		}
		$conn->delete_container("wp_cdntools");
		update_option('cdntools_baseuri','');
		update_option('cdntools_loadedfiles','');
	}

	function add_admin_pages(){
		add_submenu_page('options-general.php', "CDN Tools", "CDN Tools", 10, "cdn-tools.php",
		array($this,"settings_output"));
	}

	function settings_output(){
		global $wp_scripts;
		if ( isset( $_POST['action'] ) ) {
			switch ( $_POST['action'] ) {
				case 'cloudfiles_cdn_load':
					$this->cloudfiles_cdn_load();
					$this->cdntools_baseuri = get_option('cdntools_baseuri');
					$this->cdntools_loadedfiles = unserialize(get_option('cdntools_loadedfiles')); //if nothing is loaded this will trigger an E_NOTICE
				break;
				case 'cloudfiles_cdn_remove':
					$this->cloudfiles_cdn_remove();
					$this->cdntools_baseuri = null;
					$this->cdntools_loadedfiles = null;
				break;
				case 'cloudfiles_cdn_update':
					$this->cloudfiles_cdn_remove();
					$this->cloudfiles_cdn_load();
					$this->cdntools_baseuri = get_option('cdntools_baseuri');
					$this->cdntools_loadedfiles = unserialize(get_option('cdntools_loadedfiles')); //if nothing is loaded this will trigger an E_NOTICE					
				break;
			}
		}
	?>
		<div class="wrap">
			<h2>CDN Tools</h2>
			<form method="post" action="options.php">
				<?php wp_nonce_field('update-options');?>
				<table class="form-table">
					<tr>
						<th>Use Google AJAX CDN:</th>
						<td><select name="cdntools_googleajax">
							<?php
							$true = null;
							$false = null;
							$set = 'selected="selected"';
							($this->cdntools_googleajax)?$true=$set:$false=$set;
							?>
							<option value="1" <?php echo $true?>>True</option>
							<option value="0" <?php echo $false?>>False</option>
							</select></td>
					</tr>
					<tr>
						<td colspan="2">Google libraries will replace prototype and jquery.  Google will trump any other CDN you have enabled as well.</td>
					</tr>
					<tr>
						<th>Primary CDN:</th>
						<td><select name="cdntools_primarycdn">
							<?php
							$amazon = null;
							$cloudfiles = null;
							$none = null;
							switch($this->cdntools_primarycdn) {
								case "cloudfiles":
									$cloudfiles = 'selected="selected"';
								break;
								case "amazon":
									$amazon = 'selected="selected"';
								break;
								default:
									$none = 'selected="selected"';
								break;
							}
							?>
							<option value="0" <?php echo $none?>>None</option>
							<option value="cloudfiles" <?php echo $cloudfiles?>>Cloud Files</option>
							<!--option value="amazon" <?php echo $amazon?>>Amazon CloudFront</option-->
							</select></td>
					</tr>
					<tr>
						<td colspan="2">Select none if you do not have a CDN account and wish to only use Google's CDN for prototype and jquery.</td>
					</tr>
					<tr>
						<th>Don't Load Admin Files:</th>
						<?php
						$adminupcheck = ($this->cdntools_ignoreadmin)?'checked="checked"':'';
						?>
						<td><input type="checkbox" name="cdntools_ignoreadmin" value="1" <?php echo $adminupcheck; ?> />
					<tr>
						<td colspan="2">Check this if you don't want the wp-admin javascript files to be put on your CDN</td>
					</tr>
					<tr class="cdn-auth">
						<th>Username:</th>
						<td><input type="text" name="cdntools_authname" value="<?php echo $this->cdntools_authname; ?>" /></td>
					</tr>
					<tr class="cnd-auth">
						<th>API Key:</th>
						<td><input type="text" style="width:260px" name="cdntools_authkey" value="<?php echo $this->cdntools_authkey; ?>" /></td>
					</tr>
				</table>
				<input type="hidden" name="action" value="update" />
				<input type="hidden" name="page_options" value="cdntools_googleajax,cdntools_primarycdn,cdntools_authname,cdntools_authkey,cdntools_ignoreadmin" />
				<p class="submit">
					<input type="submit" class="button-primary" value="Save Changes" />
			</form>
			<?php 
			if (!$none) {
				$cdnstatus = ( is_array( $this->cdntools_loadedfiles ) )?'<span style="color:green">Populated</span>':'<span style="color:red">Unpopulated</span>';
				?>
				<h3>CDN Status : <?php echo $cdnstatus; ?></h3>
				<table id="cdn_status">
				<?php 
				if( !is_array( $this->cdntools_loadedfiles ) ) { ?>
					<form method="post" action="">
						<tr><td>
							<input type="hidden" name="action" value="cloudfiles_cdn_load" />
							<input type="submit" class="button-primary" value="Populate CDN Data" />
						</td></tr>
						<tr>
						<td>This will take awhile. Be patient during the reload.</td>
						</tr>
					</form>
				<?php 
				} else { ?>
					<tr><td>
						<select>
							<option>List of Loaded Scripts</option>
							<?php
 							foreach($this->cdntools_loadedfiles as $value) {
								echo '<option>'.$value.'</option>'."\n";
							} 
?>
						</select>
					</td></tr>
					<form method="post" action="">
						<input type="hidden" name="action" value="cloudfiles_cdn_update" />
						<tr><td><input type="submit" class="button-primary" value="Update CDN Data" /></td>
					</form>
					<form method="post" action="">
						<input type="hidden" name="action" value="cloudfiles_cdn_remove" />
						<td><input type="submit" class="button-primary" value="Remove CDN Data" /></td></tr>
					</form>
				<?php
 				}?>
				</table> 
			<?php
			}?>
		</div>
		<?php 
		/*foreach($wp_scripts->registered as $object) {
			echo $object->handle.' '.$object->src.' ';
			print_r($object->deps);
			echo '<br>';
		}*/
	}
}

?>