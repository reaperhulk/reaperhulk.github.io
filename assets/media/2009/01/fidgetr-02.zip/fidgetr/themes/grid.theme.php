<div id="fidgetr_container" style="width:100%;text-align:center;position:relative">
<script type="text/javascript">
for(var x in fidgetrObject.photo) {
	document.write('<a class="fidgetr_link" href="'+fidgetrObject.photo[x].flickr+'" title="'+fidgetrObject.photo[x].title+'" target="_blank"><img style="border:0px" src="'+fidgetrObject.photo[x].url_s+'" /></a>');
/*	if(fidgetrObject.photo[x].comments.length > 0) {
		for(var y in fidgetrObject.photo[x].comments) {
			var commentObj = fidgetrObject.photo[x].comments[y];
			jQuery(".fidgetr_commentcontainer").append('<div>\n<p>'+commentObj._content+'</p>\n<p class="fidgetr_commentdata">\n<span style="float:left">-<a href="http://flickr.com/photos/'+commentObj.author+'" target="_blank">'+commentObj.authorname+'</a></span><a href="'+commentObj.permalink+'" target="_blank">'+commentObj.datecreate+'</a>\n</p>\n</div>\n');
		}
	}*/
}
</script>
</div>
<script type="text/javascript">
var timeOutId = 0;
jQuery(document).ready(function() {
	jQuery(".fidgetr_link > img:first-child[src]").parent().slimbox({}, function(el) {
		return [el.firstChild.src.replace(/_[mts]\.(\w+)$/, ".$1"),
		'<a href="' + el.href + '">'+el.title+' &rarr;</a>'];
	});

	jQuery("#fidgetr_container div").bind("mouseenter mouseleave", function() {
		var comments = jQuery(this).find(".fidgetr_commentcontainer");
		comments.toggle("fast");
	});

});
</script>