<?php
class flickrApi {
	private $api_key = '37718025c9d25aaa2f1199d8886d43a4';
	private $format = 'php_serial';
	private $user_id = '';
	

	public $username = '';
	public $urlArr = '';
	public $commentsArr = '';
	
	public function getNsid($username) {
		$this->username = $username;
		$params['method'] = 'flickr.people.findByUsername';
		$params['api_key'] = $this->api_key;
		$params['format'] = $this->format;
		$params['username'] = $this->username;
		$responseObj = $this->apiReq($params);
		if($responseObj) {
			$this->user_id = $responseObj['user']['nsid'];
			return true;
		} else {
			return false;
		}

	}
	
	public function getPublicPhotos($per_page=10) {
		$params['method'] = 'flickr.people.getPublicPhotos';
		$params['api_key'] = $this->api_key;
		$params['format'] = $this->format;
		$params['user_id'] = $this->user_id;
		$params['per_page'] = $per_page;
		$responseObj = $this->apiReq($params);
		$this->buildPhotoUrlArray($responseObj['photos']['photo']);
	}
	
	//this function expects a multidimensional array sourced from getPublicPhotos
	public function getPhotoComments() {
		$params['method'] = 'flickr.photos.comments.getList';
		$params['api_key'] = $this->api_key;
		$params['format'] = $this->format;
		foreach ($this->urlArr as $key=>$value) {
			$params['photo_id'] = $value['photo_id'];
			$responseObj = $this->apiReq($params);
			$this->commentsArr[$value['photo_id']] = $responseObj['comments']; //add the comments to the comments only array
			$this->urlArr[$key]['comments'] = $responseObj['comments']; //add the comments to the combined array
		}
	}

	private function apiReq($params) {
		foreach ($params as $key=>$value) {
			$encodedParams[] = urlencode($key).'='.urlencode($value);
		}
		$url = 'http://api.flickr.com/services/rest/?'.implode('&', $encodedParams);
		$response = file_get_contents($url); //may need to change this for servers sans url_fopen
		$responseObj = unserialize($response);
		if($responseObj['stat'] == "ok") {
			return $responseObj;
		} else {
//			$this->error($responseObj);
			return false;
		}
	}
	
	private function buildPhotoUrlArray($photo) {
		$size = "m";
		foreach ($photo as $value) {
			extract($value);
			$urlArr[] = array(
				'url'=>"http://farm$farm.static.flickr.com/$server/{$id}_{$secret}_{$size}.jpg",
				'flickr'=>"http://www.flickr.com/photos/{$this->user_id}/$id",
				'title'=>$title,
				'photo_id'=>$id
			);
		}
		$this->urlArr = $urlArr;
	}
			
	private function error($responseObj) {
		echo 'status: '.$responseObj['stat']."\ncode: ".$responseObj['code']."\nmessage: ".$responseObj['message']."\n";
		exit;
	}
}
?>