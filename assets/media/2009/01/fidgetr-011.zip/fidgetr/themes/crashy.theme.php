<div id="fidgetr_container">
<script type="text/javascript">
for(var x in fidgetrObject.photo) {
	if(x==1) {
		document.write('<div id="fidgetr_hidden" style="display:none;width:240px">')
	}
	document.write('<div class="fidgetr_item"><p><span style="font-size:8pt">'+fidgetrObject.photo[x].title+'</span><br/><a href="'+fidgetrObject.photo[x].flickr+'" target="_blank"><img style="border:0px" src="'+fidgetrObject.photo[x].url+'" /></a></p><div style="position:fixed;display:none;width:100px;background:#fff;border:1px solid;-webkit-border-radius:3px;-moz-border-radius:3px" class="comments"><p>comment 1</p><p>comment 2</p></div></div>\n');
}
var timeOutId = 0;
jQuery(document).ready(function() {
	jQuery("#fidgetr_container").bind("mouseenter", function() {
		clearTimeout(timeOutId);
		jQuery("#fidgetr_hidden").show("slow");
	});
	jQuery("#fidgetr_container").bind("mouseleave", function() {
		timeOutId = setTimeout(function() {
			jQuery("#fidgetr_hidden").hide("slow");
		}, 800);
	});

	jQuery("#fidgetr_container .fidgetr_item").bind("mouseenter mouseleave", function() {
		var comments = jQuery(this).find("div");
		var pos = jQuery(this).find("img").offset();
		comments.get(0).style.left = 1000+"px";
		comments.get(0).style.top = 1000 + "px";
//		comments.css( {"left": (parseInt(pos.left)-100) + "px", "top":pos.top + "px"});
		comments.toggle("slow");
	});
});
</script>
</div>
</div>