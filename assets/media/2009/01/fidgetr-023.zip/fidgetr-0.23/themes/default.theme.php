<div id="fidgetr_container">
<!--this needs a rewrite using JS objects properly. no more document.write...-->
<script type="text/javascript">
for(var x in fidgetrObject.photo) {
	if(x==1) {
		document.write('<div id="fidgetr_hidden">');
	}
	document.write('<div class="fidgetr_item">\n<p>\n<span>'+fidgetrObject.photo[x].title+'</span><a href="'+fidgetrObject.photo[x].flickr+'" target="_blank"><img src="'+fidgetrObject.photo[x].url_m+'" /></a></p>\n');
	if(fidgetrObject.photo[x].comment != null) {
		document.write('<div class="fidgetr_commentcontainer">\n');
		for(var y in fidgetrObject.photo[x].comment) {
			var commentObj = fidgetrObject.photo[x].comment[y]
			document.write('<div>\n<p>'+commentObj._content+'</p>\n<p class="fidgetr_commentdata">\n<span style="float:left">-<a href="http://flickr.com/photos/'+commentObj.author+'" target="_blank">'+commentObj.authorname+'</a></span><a href="'+commentObj.permalink+'" target="_blank">'+commentObj.datecreate+'</a>\n</p>\n</div>\n');
		}
		document.write('</div>\n');
	}
	document.write('</div>\n');
}

var timeOutId = 0;
jQuery(document).ready(function() {
	jQuery("#fidgetr_container").fadeTo(1500,1.0);
	jQuery("#fidgetr_container").bind("mouseenter", function() {
		clearTimeout(timeOutId);
		jQuery("#fidgetr_hidden").show("slow");
	});
	jQuery("#fidgetr_container").bind("mouseleave", function() {
		timeOutId = setTimeout(function() {
			jQuery("#fidgetr_hidden").hide("slow");
		}, 800);
	});
	
	jQuery("#fidgetr_container .fidgetr_item").bind("mouseenter mouseleave", function() {
		var comments = jQuery(this).find(".fidgetr_commentcontainer");
		comments.toggle("fast");
	});

});
</script>
</div>
</div>