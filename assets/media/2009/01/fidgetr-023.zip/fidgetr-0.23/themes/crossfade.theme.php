<div id="fidgetr_container" style="position:relative;width:100%;height:240px">
	<div class="fidgetr_fade">
<script type="text/javascript">
for(var x in fidgetrObject.photo) {
	if (x==0) {
		document.write('<label class="fidgetr_img"><a href="'+fidgetrObject.photo[x].flickr+'" target="_blank"><img style="border:0px" src="'+fidgetrObject.photo[x].url_m+'" /></a></label>');
	} else {
		document.write('<div class="fidgetr_img"><a href="'+fidgetrObject.photo[x].flickr+'" target="_blank"><img style="border:0px" src="'+fidgetrObject.photo[x].url_m+'" /></a></div>');
	}
}

// when the DOM is ready:  
jQuery(document).ready(function () {  
	// find the div.fade elements and hook the hover event  
	var height = jQuery('div.fidgetr_fade img:first-child').height();
	jQuery('#fidgetr_container').css("height",height+"px");
	imageRotator(0);
});	 
var fade = jQuery('.fidgetr_img');
function imageRotator(index) {
	if(!index || index > (parseInt(fade.length)-1)) {
		index = 0;
		var prevIndex = parseInt(fade.length)-1;
	} else {
		var prevIndex = parseInt(index)-1;
	}
	console.log(index);
	console.log(fade[index].innerHTML);
	jQuery(fade[index]).fadeIn(2000);
	jQuery(fade[prevIndex]).fadeOut(2000);
	setTimeout('imageRotator('+(index+1)+')', 5000);
}
</script>
</div>
</div>