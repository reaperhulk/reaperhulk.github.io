=== Fidgetr ===
Contributors: reaperhulk
Donate link: http://www.swearingscience.com/fidgetr
Tags: flickr, photos, widgets
Requires at least: 2.5
Tested up to: 2.7
Stable tag: trunk

A simple and beautiful Flickr widget that supports themes.

== Description ==

[Fidgetr](http://www.swearingscience.com/fidgetr/ "Fidgetr Home") is a WordPress widget that displays the latest photos from your Flickr photostream in an attractive manner.  It features support for its own themes along with very simple setup and compatibility with most WordPress themes.

[View changelog](http://www.swearingscience.com/fidgetr/ "Fidgetr Home").

== Installation ==

1. Upload fidgetr/ into wp-content/plugins/
2. Activate the plugin via the 'Plugins' menu.
3. Add/configure the widget via the 'Widgets' option under Themes.

To add themes to your Fidgetr install, copy the theme file to fidgetr/themes/ and any support files to fidgetr/themes/theme_files/theme_name

== Theme Development FAQ ==

= How do I make a theme? =
Check out the basic.theme.php file in the themes directory to see a very basic example of how to parse the JSON structure that fidgetr outputs. You can also write PHP.

= How do I make new themes show up in the configuration dropdown? =
Simply create a file called yourname.theme.php with your data.  If you have a CSS/JS supplement add those support files in a directory theme_includes/yourname/

Please note that in Fidgetr javascript files have a very strict naming structure to allow proper queueing via WP and reduce conflicts with other plugins.  Your file must be named handle-ver-deps.js.  *Do not use - or _ in the handle as they are delimiters.*  Additionally, ver must be numeric.  Multiple deps can be provided via underscore.  Examples: slimbox-2.01-jquery.js , somelib-1.0-jquery_jquery-ui-core.js.  Be sure to name your scripts correctly to avoid conflicts with other wordpress plugins.


== Screenshots ==

1. The default theme displaying a single image.
2. The configuration panel for the widget.

== License ==

    Copyright 2009 Paul Kehrer

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA