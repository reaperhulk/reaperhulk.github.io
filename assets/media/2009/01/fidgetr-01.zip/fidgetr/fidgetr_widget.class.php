<?php
class fidgetr_widget {
	public function renderJsonOutput($urlArr) {
		?>
		<script type="text/javascript">
		
		var fidgetrData =
			{
				"photo":
				[
<?
		foreach($urlArr as $value) {
			$elementArr[] = "		{
						\"flickr\": \"{$value['flickr']}\",
						\"url\": \"{$value['url']}\",
						\"title\": \"{$value['title']}\",
						\"comments\": [\n".$this->jsonCommentsOutput($value['comments']['comment']).
"\n						]
					}";
		}
		echo implode(",\n",$elementArr);
?>						
				]
			}
		var fidgetrObject = eval(fidgetrData);
		</script>
		<?
	}
	
	public function renderWidget($theme) {
		$themeData = file_get_contents(dirname(__FILE__)."/themes/$theme.theme.php");
		echo $themeData;
	}
	
	private function jsonCommentsOutput($comments) {
		if(isset($comments)) {
			foreach ($comments as $value) {
				$value['datecreate'] = date('d/m/y H:i',$value['datecreate']); //return human readable time out of the timestamp.
				$commentsjson[] = "{
									\"author\": \"{$value['author']}\",
									\"authorname\": \"{$value['authorname']}\",
									\"datecreate\": \"{$value['datecreate']}\",
									\"permalink\": \"{$value['permalink']}\",
									\"_content\": \"{$value['_content']}\"
									}";
			}
			if (isset($commentsjson)) {
				return implode(",\n",$commentsjson);
			}
		}
	}
}
?>