<?php
/*
	Plugin Name: Fidgetr
	Plugin URI: http://www.swearingscience.com/fidgetr
	Description: A themeable widget that can fetch pictures and comments and style them in a myriad of attractive ways.
	Version: 0.1
	Author: Paul Kehrer
	Author URI: http://www.swearingscience.com/
*/

require_once("flickrApi.class.php");
require_once("fidgetr_widget.class.php");

//load list of available themes
$theme_choices = scandir(dirname(__FILE__)."/themes/");
foreach($theme_choices as $key=>$value) {
	if(strlen($value) > 10 && strpos($value,".css") === false) {
		$theme_choices[$key] = substr($value,0,strpos($value,'.theme.php'));
	} else {
		unset($theme_choices[$key]);
	}
}

$fidgetr_options['title'] = array('label'=>'Title:', 'type'=>'text', 'default'=>'Fidgetr');
$fidgetr_options['username'] = array('label'=>'Username:', 'type'=>'text', 'default'=>'Paul Kehrer');
$fidgetr_options['num'] = array('label'=>'# of Photos:', 'type'=>'text', 'default'=>'4');
$fidgetr_options['cachetime'] = array('label'=>'Cache Time (s):', 'type'=>'text', 'default'=>'7200');
$fidgetr_options['commentsflag'] = array('label'=>'Fetch Comments:', 'type'=>'checkbox', 'default'=>'');
$fidgetr_options['theme'] = array('label'=>'Theme:', 'type'=>'dropdown', 'default'=>'default', 'options'=>$theme_choices);

function fidgetr_css() {   
	if (!defined('WP_CONTENT_URL')) {
		define('WP_CONTENT_URL', get_option('siteurl') . '/wp-content');
	}
	$options = get_option('widget_fidgetr');
	$path = WP_CONTENT_URL . '/plugins/fidgetr/themes/'.$options['theme'].'_fidgetr.css';
	if (file_exists(dirname(__FILE__)."/themes/{$options['theme']}_fidgetr.css")) {
		//include css only if the file exists.  themes do not necessarily require separate css
		echo '<!--fidgetr insert head-->'."\n";
		echo '<link rel="stylesheet" type="text/css" href="' . $path . '" />'."\n";
		echo '<!--fidgetr end insert-->';
	}
}



function fidgetr_images($options) {
	//timing functions
	$start = microtime(true);
	
	if(isset($options['datacache'])) {
		$dataCache = unserialize($options['datacache']);
	}
	if( (time() - $dataCache['lastupdate'] > $options['cachetime']) || (!isset($dataCache)) || (!isset($dataCache['urlArr'])) || ($dataCache['username'] != $options['username']) || ($dataCache['num'] != $options['num']) || ($dataCache['commentsflag'] != $options['commentsflag']) || ($dataCache['theme'] != $options['theme']) ) {
		//if it has been more than cachetime, there is no data cache, certain options have changed (# of photos, username, comment flag, theme), or the urlArr is empty we need to fetch data.
		$f = new flickrApi();
		$f->getNsid($options['username']);
		$f->getPublicPhotos((int)$options['num']);
		if($options['commentsflag']) {
			$f->getPhotoComments();
		}
		$options['generated'] = date('m/d/Y G:i:s',time());
		//write a cache file to prevent constant queries to flickr.  no conflict with wp super cache.
		$options['datacache'] = serialize(array('lastupdate'=>time(),'num'=>$options['num'],'username'=>$options['username'],'commentsflag'=>$options['commentsflag'],'urlArr'=>$f->urlArr,'theme'=>$options['theme']));
		update_option('widget_fidgetr', $options);
	} else {
		$f = new flickrApi();
		$f->urlArr = $dataCache['urlArr'];
	}
	$o = new fidgetr_widget();
	$o->renderJsonOutput($f->urlArr);
	$o->renderWidget($options['theme']);
	
	//timing functions
	$end = microtime(true);
	$time_taken = round(($end-$start)*1000,0);
	echo "\n<!--last fetched: {$options['generated']} -->\n";
	echo "<!--Generated in $time_taken milliseconds-->\n";
}


function widget_fidgetr_init() {

	if (!function_exists('register_sidebar_widget')) {
		//if we don't have that function, we can't load this plugin.
		return;
	}
  
	function widget_fidgetr($args) {
		global $fidgetr_options;
		
		// $args is an array of strings that help widgets to conform to
		// the active theme: before_widget, before_title, after_widget,
		// and after_title are the array keys. Default tags: li and h2.
		extract($args);

		// load our options from the DB
		$options = get_option('widget_fidgetr');
		
		// actual output of widget
		echo $before_widget . $before_title . $options['title'] . $after_title;
		fidgetr_images($options);
		echo $after_widget;
	}

	// widget form in wp-admin
	function widget_fidgetr_control() {
		global $fidgetr_options;

		// Get our options and see if we're handling a form submission.
		if (isset($_POST['fidgetr-submit'])) {
			//if wp super cache is installed we need to invalidate the cache when options are changed.  otherwise let it do its thing.
			if(function_exists('wp_cache_no_postid')) {
				wp_cache_no_postid(0);
			}
			
			//set all options to defaults
			foreach($fidgetr_options as $key => $value) {
				$options[$key] = $value['default'];
			}

			//set title
			$options['title'] = strip_tags(stripslashes($_POST['fidgetr_title']));
			//test username, only valid flickr names allowed
			$f = new flickrApi();
			if ($f->getNsid($_POST['fidgetr_username'])) {
				$options['username'] = $_POST['fidgetr_username'];
			} else {
				$fidgetr_username_error = "";
			}
			//test range # of photos
			if(101 > ((int)$_POST['fidgetr_num']) && ((int)$_POST['fidgetr_num']) > 0) {
				$options['num'] = $_POST['fidgetr_num'];
			} else {
				$fidgetr_num_error = "";
			}
			//set cache time
			$options['cachetime'] = (int)$_POST['fidgetr_cachetime'];
			//set comments flag
			if($_POST['fidgetr_commentsflag']) {
				$options['commentsflag'] = 1;
			}
			//set theme
			$options['theme'] = strip_tags(stripslashes($_POST['fidgetr_theme']));

			update_option('widget_fidgetr', $options);
		}

		$options = get_option('widget_fidgetr');
		// fill options with default values if value is not set
		foreach($fidgetr_options as $key => $value) {
			if (!isset($options[$key])) {
				$options[$key] = $value['default'];
			}
		}
		update_option('widget_fidgetr', $options);

		//this section should be targeted for a rewrite soon
		foreach($fidgetr_options as $key => $value) {
			$field_name = 'fidgetr_'.$key;
			$field_checked = '';
			if ($value['type'] == 'text') {
				if(!empty($options[$key])) {
					$field_value = htmlspecialchars($options[$key], ENT_QUOTES);
				}
			} elseif ($value['type'] == 'checkbox') {
				$field_value = 1;
				if (! empty($options[$key])) {
					$field_checked = 'checked="checked"';
				}
			}
			if ($value['type'] == 'text' || $value['type'] == 'checkbox') {
				printf('<p style="text-align:right;" class="fidgetr_field"><label for="%s">%s <input id="%s" name="%s" type="%s" value="%s" class="%s" %s /></label></p>',
				$field_name, __($value['label']), $field_name, $field_name, $value['type'], $field_value, $value['type'], $field_checked);
				unset($field_checked);
			} elseif ($value['type'] == 'dropdown') {
				printf('<p style="text-align:right;" class="fidgetr_field"><label for="%s">%s <select id="%s" name="%s" class="%s">',
				$field_name, __($value['label']), $field_name, $field_name, $field_name);
				foreach($value['options'] as $optionvalue) {
					if(($optionvalue == $options['theme']) || (empty($options['theme']) && $optionvalue = $fidgetr_options['theme']['default'])) {
						$options_selected = 'selected="selected"';
					}
					printf('<option value="%s" %s>%s</option',$optionvalue,$options_selected,$optionvalue);
					unset($options_selected);
				}
				printf('</select></label></p>');
			}
		}		
		echo '<input type="hidden" id="fidgetr-submit" name="fidgetr-submit" value="1" />';
	}
		
	
	function widget_fidgetr_register() {
		
		$options = get_option('widget_fidgetr');
		$dimensions = array('width' => 300, 'height' => 200);
		$class = array('classname' => 'widget_fidgetr');

		$name = "Fidgetr";
		$id = "fidgetr";
		wp_register_sidebar_widget($id, $name, 'widget_fidgetr', $class);
		wp_register_widget_control($id, $name, 'widget_fidgetr_control', $dimensions);
		
	}

	widget_fidgetr_register();
}

add_action('wp_head', 'fidgetr_css'); // include the stylesheet
// Run our code later in case this loads prior to any required plugins.
add_action('widgets_init', 'widget_fidgetr_init');

?>