<script type="text/javascript">
for(var x in fidgetrObject.photo) {
	document.write('<p><span style="font-size:8pt">'+fidgetrObject.photo[x].title+'</span><br/><a href="'+fidgetrObject.photo[x].flickr+'" target="_blank"><img style="border:0px" src="'+fidgetrObject.photo[x].url+'" /></a></p>');
}
</script>