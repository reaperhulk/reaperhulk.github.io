<div id="fidgetr_container">
	<div id="fidgetr_hidden">
	</div>
</div>
<script type="text/javascript">
for(var x in fidgetrObject.photo) {
	var itemDiv = document.createElement('div');
	itemDiv.className = 'fidgetr_item';
	itemDiv.innerHTML = '<p>\n<span>'+fidgetrObject.photo[x].title+'</span><a href="'+fidgetrObject.photo[x].flickr+'" target="_blank"><img src="'+fidgetrObject.photo[x].url_m+'" /></a></p>\n';
	if(fidgetrObject.photo[x].comment != null) {
		var commentDiv = document.createElement('div');
		commentDiv.className = 'fidgetr_commentcontainer';
		for(var y in fidgetrObject.photo[x].comment) {
			var commentObj = fidgetrObject.photo[x].comment[y];
			var newDate = new Date();
			newDate.setTime( parseInt(commentObj.datecreate)*1000 );
			dateString = newDate.toUTCString();
			commentObj.datecreate = dateString;
			var eachComment = document.createElement('div');
			eachComment.innerHTML = '<p>'+commentObj._content+'</p>\n<p class="fidgetr_commentdata">\n<span style="float:left">-<a href="http://flickr.com/photos/'+commentObj.author+'" target="_blank">'+commentObj.authorname+'</a></span><a href="'+commentObj.permalink+'" target="_blank">'+commentObj.datecreate+'</a>\n</p>';
			jQuery(eachComment).appendTo(jQuery(commentDiv));
		}
		jQuery(commentDiv).appendTo(jQuery(itemDiv));
	}
	if(x==0) {
		jQuery('#fidgetr_container').prepend(itemDiv);
	} else {
		jQuery('#fidgetr_hidden').append(itemDiv);
	}
}

var timeOutId = 0;
jQuery(window).load(function() {
	jQuery("#fidgetr_container").fadeTo(1500,1.0);

	//this block unhides and rehides the commentcontainers very rapidly to obtain the offset.
	//with this info we know if the sidebar is on the left or right
	var firstComment = jQuery(".fidgetr_commentcontainer:first");
	var fidgetrHidden = jQuery("#fidgetr_hidden");
	var width = jQuery(".fidgetr_item > p > a > img:first").width()+1;
	fidgetrHidden.css("display","block");
	firstComment.css("display","block");
	var lrCheck = firstComment.offset();
	fidgetrHidden.css("display","none");
	firstComment.css("display","none");
	if(lrCheck && lrCheck.left < 100) { // must be a left sidebar, flip the comment location
		jQuery(".fidgetr_commentcontainer").css("left",width+"px");
	}
	//end sidebar check logic

});
jQuery(document).ready(function() {
	
	jQuery("#fidgetr_container").bind("mouseenter", function() {
		clearTimeout(timeOutId);
		jQuery("#fidgetr_hidden").show("slow");
	});
	jQuery("#fidgetr_container").bind("mouseleave", function() {
		timeOutId = setTimeout(function() {
			jQuery("#fidgetr_hidden").hide("slow");
		}, 800);
	});
	
	jQuery("#fidgetr_container .fidgetr_item").bind("mouseenter mouseleave", function() {
		var comments = jQuery(this).find(".fidgetr_commentcontainer");
		comments.toggle("fast");
	});

});
</script>