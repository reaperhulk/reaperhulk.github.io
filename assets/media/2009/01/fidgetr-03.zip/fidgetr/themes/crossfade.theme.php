<div id="fidgetr_container" style="position:relative;width:100%;">
	<div class="fidgetr_fade">
<script type="text/javascript">
for(var x in fidgetrObject.photo) {
	if (x==0) {
		document.write('<div class="fidgetr_item" style="display:block"><span>'+fidgetrObject.photo[x].title+'</span><a href="'+fidgetrObject.photo[x].flickr+'" target="_blank"><img style="border:0px" src="'+fidgetrObject.photo[x].url_m+'" /></a>');
	} else {
		document.write('<div class="fidgetr_item"><span>'+fidgetrObject.photo[x].title+'</span><a href="'+fidgetrObject.photo[x].flickr+'" target="_blank"><img style="border:0px" src="'+fidgetrObject.photo[x].url_m+'" /></a>');
	}
	if(fidgetrObject.photo[x].comment != null) {
		document.write('<div class="fidgetr_commentcontainer">\n');
		for(var y in fidgetrObject.photo[x].comment) {
			var commentObj = fidgetrObject.photo[x].comment[y];
			var newDate = new Date();
			newDate.setTime( parseInt(commentObj.datecreate)*1000 );
			dateString = newDate.toUTCString();
			commentObj.datecreate = dateString;
			document.write('<div>\n<p>'+commentObj._content+'</p>\n<p class="fidgetr_commentdata">\n<span style="float:left">-<a href="http://flickr.com/photos/'+commentObj.author+'" target="_blank">'+commentObj.authorname+'</a></span><a href="'+commentObj.permalink+'" target="_blank">'+commentObj.datecreate+'</a>\n</p>\n</div>\n');
		}
		document.write('</div>\n');
	}
	document.write('</div>\n');	
}

jQuery(window).load(function () {
	var height = 0;
	jQuery('.fidgetr_item').each(function() {
		if(jQuery(this).height() > height) {
			height = jQuery(this).height();
		}
	});
	jQuery('#fidgetr_container').animate( { height: height+"px" },500);

	//this block unhides and rehides the commentcontainers very rapidly to obtain the offset.
	//with this info we know if the sidebar is on the left or right
	var firstComment = jQuery(".fidgetr_commentcontainer:first");
	jQuery(".fidgetr_item").css("display","block");
	firstComment.css("display","block");
	var lrCheck = firstComment.offset();
	jQuery(".fidgetr_item").css("display","none");
	jQuery(".fidgetr_item:first").css("display","block");
	firstComment.css("display","none");
	if(lrCheck && lrCheck.left < 100) { // must be a left sidebar, flip the comment location
		var width = jQuery(".fidgetr_item img:first").width()+1;
		jQuery(".fidgetr_commentcontainer").css("left",width+"px");
	}
	//end sidebar check logic

})

jQuery(document).ready(function () {  
	imageRotator(0,5000);
	jQuery(".fidgetr_item").bind("mouseenter", function() {
		var comments = jQuery(this).find(".fidgetr_commentcontainer");
		comments.toggle("fast");
		clearTimeout(timeOutId);
	});
	jQuery(".fidgetr_item").bind("mouseleave", function() {
		var comments = jQuery(this).find(".fidgetr_commentcontainer");
		comments.toggle("fast");
		var whichVisible = jQuery('.fidgetr_item');
		var i = 0;
		whichVisible.each(function () {
			if(jQuery(this).is(':visible')) {
				imageRotator(i);
			}
			i++;
		});
	});
});	
var timeOutId = 0;
var fade = jQuery('.fidgetr_item');
function imageRotator(index) {
	if(!index || index > (parseInt(fade.length)-1)) {
		index = 0;
		var prevIndex = parseInt(fade.length)-1;
	} else {
		var prevIndex = parseInt(index)-1;
	}
	jQuery(fade[index]).fadeIn(2500);
	jQuery(fade[prevIndex]).fadeOut(2500);
	timeOutId = setTimeout('imageRotator('+(index+1)+')', 5000);
}
</script>
</div>
</div>