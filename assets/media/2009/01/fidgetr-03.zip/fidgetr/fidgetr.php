<?php
/*
	Plugin Name: Fidgetr
	Plugin URI: http://www.swearingscience.com/fidgetr
	Description: A themeable Flickr widget that can fetch pictures and comments and style them in a myriad of attractive ways.
	Version: 0.3
	Author: Paul Kehrer
	Author URI: http://www.swearingscience.com/
*/

require_once("flickrApi.class.php");

//instantiate our object
$fidgetr = new fidgetr_widget();

//pretty safe to assume we would like jquery available for use within all themes
wp_enqueue_script('jquery');
//includes must be run twice.  once for JS and once for CSS.
$fidgetr->_includes(true); //queue up any theme JS
add_action('wp_head', array($fidgetr, '_includes')); // include theme CSS if necessary

//hook to the widgets_init to start the whole widget
add_action('widgets_init', array($fidgetr, '_init'));



class fidgetr_widget {
	private $fidgetr_options = '';
	private $options = '';
	private $siteurl = '';
	private $theme_choices = array();
	private $version = '0.3';


	public function __construct() {
		//load our options.  single load per class instantiation.
		$this->options = get_option('widget_fidgetr');
		$this->siteurl = get_option('siteurl');
		//load list of available themes.  the whole widget will fail if the themes dir is missing.
		$this->theme_choices = scandir(dirname(__FILE__)."/themes/");
		foreach($this->theme_choices as $key=>$value) {
			if(strlen($value) > 10 && strpos($value,".theme.php") > 0) {
				$this->theme_choices[$key] = substr($value,0,strpos($value,'.theme.php'));
			} else {
				unset($this->theme_choices[$key]);
			}
		}
		//setup our default options
		$this->fidgetr_options = array(
		'title'=>array('name'=>'Title:', 'type'=>'text', 'default'=>'Fidgetr'),
		'username'=>array('name'=>'Username:', 'type'=>'text', 'default'=>'Paul Kehrer'),
		'num'=>array('name'=>'# of Photos:', 'type'=>'text', 'default'=>'4'),
		'cachetime'=>array('name'=>'Cache Time (s):', 'type'=>'text', 'default'=>'7200'),
		'commentsflag'=>array('name'=>'Fetch Comments:', 'type'=>'checkbox', 'default'=>''),
		'theme'=>array('name'=>'Theme:', 'type'=>'dropdown', 'default'=>'default', 'options'=>$this->theme_choices)
		);
		
	}


	public function _includes($jsenqueue=false) {   
		if (!defined('WP_CONTENT_URL')) {
			define('WP_CONTENT_URL', $this->siteurl . '/wp-content');
		}
		//figure out what the fidgetr directory name is just in case they have changed it
		$fidgetr_dir_name = substr(dirname(__FILE__),strrpos(dirname(__FILE__),"/")+1);
		//build the URL path for includes
		$path = WP_CONTENT_URL . '/plugins/' . $fidgetr_dir_name .'/themes/theme_includes/'.$this->options['theme'].'/';
		if (!file_exists(dirname(__FILE__)."/themes/theme_includes/{$this->options['theme']}")) {
			return; //nothing to include
		}
		$includes = scandir(dirname(__FILE__)."/themes/theme_includes/{$this->options['theme']}");
		foreach($includes as $value) {
			if(!$jsenqueue) { //not running enqueue, so let's find the CSS
				if(strpos($value,".css") > 0) {
					echo '<!--fidgetr '.$this->version.' insert head-->'."\n";
					echo '<link rel="stylesheet" type="text/css" href="' . $path.$value . '" />'."\n";
					echo '<!--fidgetr '.$this->version.' end insert-->';
				}
			} else { //this is the enqueue portion, find all the JS and queue it up!
				if(strpos($value,".js") > 0) {
					/*
					in fidgetr javascript files have a very strict naming structure to
					allow proper queueing via WP and reduce conflicts with other plugins.
					your file must be named handle-ver-deps.js  do not use - or _ in the names 
					as they are delimiters.  additionally, ver must be numeric.  multiple deps can 
					be provided via underscore (ex: handle-ver-dep1_dep2_dep3.js)
					*/
					preg_match("/^(.+?)-([^\-]+)(?:-(.+))?\.js$/",$value,$matches);
					if(isset($matches[3]) && strpos($matches[3],"_") == 0) {
						$deps = array($matches[3]);
					} elseif(strpos($matches[3],"_") > 0) {
						$deps = explode("_",$matches[3]);	
					} else {
						$deps = false;
					}
					(is_numeric($matches[2]))?$ver=$matches[2]:$ver=false;
					// enqueue script takes the following args
					// handle, path, dependencies, version
					wp_enqueue_script( $matches[1], $path.$value, $deps, $ver);
				}
			}
		}
	}


	private function fidgetr_images() {
		//timing functions
		$start = microtime(true);
	
		if(isset($this->options['datacache'])) {
			$dataCache = unserialize($this->options['datacache']);
		}
		if( (time() - $dataCache['lastupdate'] > $this->options['cachetime']) || 
		(!isset($dataCache)) || 
		(!isset($dataCache['urlArr'])) || 
		($dataCache['username'] != $this->options['username']) || 
		($dataCache['num'] != $this->options['num']) || 
		($dataCache['commentsflag'] != $this->options['commentsflag']) || 
		($dataCache['theme'] != $this->options['theme']) ) {
			//if it has been more than cachetime, there is no data cache, certain options have changed (# of photos, username, comment flag, theme), or the urlArr is empty we need to fetch data.
			$f = new flickrApi();
			$f->getNsid($this->options['username']);
			$f->getPublicPhotos((int)$this->options['num']);
			if($this->options['commentsflag']) {
				$f->getPhotoComments();
			}
			$this->options['generated'] = date('m/d/Y G:i:s',time());
			//write a cache file to prevent constant queries to flickr.  no conflict with wp super cache.
			$this->options['datacache'] = serialize(array('lastupdate'=>time(),'num'=>$this->options['num'],'username'=>$this->options['username'],'commentsflag'=>$this->options['commentsflag'],'urlArr'=>$f->urlArr,'theme'=>$this->options['theme']));
			update_option('widget_fidgetr', $this->options);
		} else {
			$f = new flickrApi();
			$f->urlArr = $dataCache['urlArr'];
		}
		$this->renderJsonOutput($f->urlArr);
		$themeData = file_get_contents(dirname(__FILE__)."/themes/{$this->options['theme']}.theme.php");
		echo $themeData;
	
		//timing functions
		$end = microtime(true);
		$time_taken = round(($end-$start)*1000,0);
		echo "\n<!--last fetched: {$this->options['generated']} -->\n";
		echo "<!--Generated in $time_taken milliseconds-->\n";
	}


	public function _output($args) {
		// $args is an array of strings that help widgets to conform to
		// the active theme: before_widget, before_title, after_widget,
		// and after_title are the array keys. Default tags: li and h2.
		extract($args);
	
		// actual output of widget
		echo $before_widget . $before_title . $this->options['title'] . $after_title;
		$this->fidgetr_images();
		echo $after_widget;
	}

	private function renderJsonOutput($urlArr) {
		?><script type="text/javascript">
			var fidgetrData =
				{
					"photo":
		<?
			echo $this->array2json($urlArr);
		?>}
		var fidgetrObject = eval(fidgetrData);</script><?
	}
	
	/*array2json provided by bin-co.com under BSD license*/
	private function array2json($arr) { 
		if(function_exists('json_encode')) return stripslashes(json_encode($arr)); //Latest versions of PHP already have this functionality. 
		$parts = array(); 
		$is_list = false; 

		//Find out if the given array is a numerical array 
		$keys = array_keys($arr); 
		$max_length = count($arr)-1; 
		if(($keys[0] == 0) and ($keys[$max_length] == $max_length)) {//See if the first key is 0 and last key is length - 1 
			$is_list = true; 
			for($i=0; $i<count($keys); $i++) { //See if each key correspondes to its position 
				if($i != $keys[$i]) { //A key fails at position check. 
					$is_list = false; //It is an associative array. 
					break; 
				} 
			} 
		} 

		foreach($arr as $key=>$value) { 
			if(is_array($value)) { //Custom handling for arrays 
				if($is_list) $parts[] = $this->array2json($value); /* :RECURSION: */ 
				else $parts[] = '"' . $key . '":' . $this->array2json($value); /* :RECURSION: */ 
			} else { 
				$str = ''; 
				if(!$is_list) $str = '"' . $key . '":'; 

				//Custom handling for multiple data types 
				if(is_numeric($value)) $str .= $value; //Numbers 
				elseif($value === false) $str .= 'false'; //The booleans 
				elseif($value === true) $str .= 'true'; 
				else $str .= '"' . addslashes($value) . '"'; //All other things 
				// :TODO: Is there any more datatype we should be in the lookout for? (Object?) 

				$parts[] = $str; 
			} 
		} 
		$json = implode(',',$parts); 

		if($is_list) return '[' . $json . ']';//Return numerical JSON 
		return '{' . $json . '}';//Return associative JSON 
	} 


	// widget form in wp-admin
	public function _control() {

		// Get our options and see if we're handling a form submission.
		if (isset($_POST['fidgetr-submit'])) {
			//if wp super cache is installed we need to invalidate the cache when options are changed.  otherwise let it do its thing.
			if(function_exists('wp_cache_no_postid')) {
				wp_cache_no_postid(0);
			}
		
			//set all options to defaults
			foreach($this->fidgetr_options as $key => $value) {
				$this->options[$key] = $value['default'];
			}

			//set title
			$this->options['title'] = strip_tags(stripslashes($_POST['fidgetr_title']));
			//test username, only valid flickr names allowed
			$f = new flickrApi();
			if ($f->getNsid($_POST['fidgetr_username'])) {
				$this->options['username'] = $_POST['fidgetr_username'];
			} else {
				$fidgetr_username_error = "";
			}
			//test range # of photos
			if(101 > ((int)$_POST['fidgetr_num']) && ((int)$_POST['fidgetr_num']) > 0) {
				$this->options['num'] = $_POST['fidgetr_num'];
			} else {
				$fidgetr_num_error = "";
			}
			//set cache time
			$this->options['cachetime'] = (int)$_POST['fidgetr_cachetime'];
			//set comments flag
			if($_POST['fidgetr_commentsflag']) {
				$this->options['commentsflag'] = 1;
			}
			//set theme
			$this->options['theme'] = strip_tags(stripslashes($_POST['fidgetr_theme']));

			update_option('widget_fidgetr', $this->options);
		}

		// fill options with default values if value is not set
		foreach($this->fidgetr_options as $key => $value) {
			if (!isset($this->options[$key])) {
				$this->options[$key] = $value['default'];
			}
		}
		update_option('widget_fidgetr', $this->options);

		//this section should be targeted for a rewrite soon
		foreach($this->fidgetr_options as $key => $value) {
			$field_name = 'fidgetr_'.$key;
			$field_checked = '';
			if ($value['type'] == 'text') {
				if(!empty($this->options[$key])) {
					$field_value = htmlspecialchars($this->options[$key], ENT_QUOTES);
				}
			} elseif ($value['type'] == 'checkbox') {
				$field_value = 1;
				if (! empty($this->options[$key])) {
					$field_checked = 'checked="checked"';
				}
			}
			if ($value['type'] == 'text' || $value['type'] == 'checkbox') {
				printf('<p style="text-align:right;" class="fidgetr_field"><label for="%s">%s <input id="%s" name="%s" type="%s" value="%s" class="%s" %s /></label></p>',
				$field_name, __($value['name']), $field_name, $field_name, $value['type'], $field_value, $value['type'], $field_checked);
				unset($field_checked);
			} elseif ($value['type'] == 'dropdown') {
				printf('<p style="text-align:right;" class="fidgetr_field"><label for="%s">%s <select id="%s" name="%s" class="%s">',
				$field_name, __($value['name']), $field_name, $field_name, $field_name);
				foreach($value['options'] as $optionvalue) {
					if(($optionvalue == $this->options['theme']) || (empty($this->options['theme']) && $optionvalue = $this->fidgetr_options['theme']['default'])) {
						$options_selected = 'selected="selected"';
					}
					printf('<option value="%s" %s>%s</option',$optionvalue,$options_selected,$optionvalue);
					unset($options_selected);
				}
				printf('</select></label></p>');
			}
		}		
		echo '<input type="hidden" id="fidgetr-submit" name="fidgetr-submit" value="1" />';
	}

	public function _init() {
		if (!function_exists('register_sidebar_widget')) {
			//if we don't have that function, we can't load this plugin.
			return;
		}
		$dimensions = array('width' => 300, 'height' => 200);
		$class = array('classname' => 'widget_fidgetr');

		$name = "Fidgetr";
		$id = "fidgetr";
		wp_register_sidebar_widget($id, $name, array($this, '_output'), $class);
		wp_register_widget_control($id, $name, array($this, '_control'), $dimensions);	
	}
}

?>