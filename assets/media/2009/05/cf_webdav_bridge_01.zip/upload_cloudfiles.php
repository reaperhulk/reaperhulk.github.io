<?php
/*
A quick WebDAV hack for redirecting data to Cloud Files
Author: Paul Kehrer

This script is based on code adapted from php iCalendar (original authors: Dietrich Ayala, Jo Rhett, Jim Hu)

Requirements
1. PHP 5.1.0 or greater is required
2. Your version of php and apache MUST support $_SERVER['PATH_INFO']
3. Curl support is required.

*/
require('cloudfiles.php');

define('DAV_LOGGING','0');

if(DAV_LOGGING == 1) {
	if( ! $logfile = fopen('publish_log.txt','a+') ) {
		header('HTTP/1.1 401 Unauthorized');
		header('WWW-Authenticate: Basic realm="ERROR: Unable to open log file"');
		echo 'Unable to open log file.';
		exit;
	}
}

if (isset($_SERVER['HTTP_AUTHORIZATION'])) {
	list($_SERVER['PHP_AUTH_USER'], $_SERVER['PHP_AUTH_PW']) = explode( ':', base64_decode( substr($_SERVER['HTTP_AUTHORIZATION'], 6) ) );
}
if (!isset($_SERVER['PHP_AUTH_USER'])) {
	header('WWW-Authenticate: Basic realm="CloudFiles"');
	header('HTTP/1.1 401 Unauthorized');
	echo 'You must be authorized!';
	exit;
}

$auth = new CF_Authentication($_SERVER['PHP_AUTH_USER'],$_SERVER['PHP_AUTH_PW']);
try {
	$auth->authenticate();
}
catch(AuthenticationException $e) {
	logmsg('CF Authentication failure');
	exit;
}
$conn = new CF_Connection($auth);
$skitch_container = $conn->create_container('skitch');
$public_uri = $skitch_container->make_public();


switch ($_SERVER['REQUEST_METHOD']){
	case 'DELETE':
		// get filename
		$file = substr($_SERVER['REQUEST_URI'] , ( strrpos($_SERVER['REQUEST_URI'], '/') + 1) ) ;
		logmsg('received request to delete '.$file);
		// remove file
		try {
			$skitch_container->delete_object($file);
		}
		catch(NoSuchObjectException $e) {
			logmsg('no such object to delete');
			exit;
		}
		catch(InvalidResponseException $e) {
			logmsg('invalid response to delete request');			
			exit;
		}

		logmsg('deleted');

	break;

	case 'PUT':
		logmsg('PUT request');
		# php://input allows you to read raw POST data
		if($datain = fopen('php://input','r')){
			while(!@feof($datain)){
				$data .= fgets($datain,4096);
			}
			@fclose($datain);
		}else{
			logmsg('unable to read input data');
		}
		if(isset($data)){
			if (isset($_SERVER['PATH_INFO'])) {
				$file_name = substr($_SERVER['PATH_INFO'],1);
			}
			logmsg('Putting file: ' . $file_name);
			// write to file
			$mime = mime_types($file_name);
			$object = $skitch_container->create_object($file_name);
			$object->content_type = $mime;
			try {
				$object->write($data);
			}
			catch(InvalidResponseException $e) {
				logmsg('Invalid response error from CF');
				exit;
			}
			catch(SyntaxException $e) {
				logmsg('Syntax exception error from CF');
				exit;
			}
			logmsg('PUT successful');
		}else {
			logmsg('PUT ERROR - No data supplied.');
		}
	break;
}

if(DAV_LOGGING == 1) {
	fclose($logfile);
}


function logmsg($str){
	global $logfile;
	if(DAV_LOGGING == 1) {
		$user =  $_SERVER['PHP_AUTH_USER'];
		$logline = date('Y-m-d H:i:s ') . $_SERVER['REMOTE_ADDR'] . ' ' . $user . ' ' . $str . "\n";
		fputs($logfile, $logline, strlen($logline) );
	}
}

//simplistic suffix array for mime type provided by svogal on php.net
function mime_types($file_name) {
	$mime_types = array(
		'txt' => 'text/plain',
		'htm' => 'text/html',
		'html' => 'text/html',
		'php' => 'text/html',
		'css' => 'text/css',
		'js' => 'application/javascript',
		'json' => 'application/json',
		'xml' => 'application/xml',
		'swf' => 'application/x-shockwave-flash',
		'flv' => 'video/x-flv',

		// images
		'png' => 'image/png',
		'jpe' => 'image/jpeg',
		'jpeg' => 'image/jpeg',
		'jpg' => 'image/jpeg',
		'gif' => 'image/gif',
		'bmp' => 'image/bmp',
		'ico' => 'image/vnd.microsoft.icon',
		'tiff' => 'image/tiff',
		'tif' => 'image/tiff',
		'svg' => 'image/svg+xml',
		'svgz' => 'image/svg+xml',

		// archives
		'zip' => 'application/zip',
		'rar' => 'application/x-rar-compressed',
		'exe' => 'application/x-msdownload',
		'msi' => 'application/x-msdownload',
		'cab' => 'application/vnd.ms-cab-compressed',

		// audio/video
		'mp3' => 'audio/mpeg',
		'qt' => 'video/quicktime',
		'mov' => 'video/quicktime',

		// adobe
		'pdf' => 'application/pdf',
		'psd' => 'image/vnd.adobe.photoshop',
		'ai' => 'application/postscript',
		'eps' => 'application/postscript',
		'ps' => 'application/postscript',

		// ms office
		'doc' => 'application/msword',
		'rtf' => 'application/rtf',
		'xls' => 'application/vnd.ms-excel',
		'ppt' => 'application/vnd.ms-powerpoint',

		// open office
		'odt' => 'application/vnd.oasis.opendocument.text',
		'ods' => 'application/vnd.oasis.opendocument.spreadsheet',
	);

	$ext = strtolower(array_pop(explode('.',$file_name)));
	if (array_key_exists($ext, $mime_types)) {
		return $mime_types[$ext];
	} else {
		return 'application/octet-stream';
	}
}
?>