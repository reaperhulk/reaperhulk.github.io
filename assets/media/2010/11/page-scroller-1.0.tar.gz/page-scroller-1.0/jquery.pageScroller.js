/*
* Copyright 2010, Paul Kehrer
* Dual licensed under the MIT or GPL Version 2 licenses.
* v1.0 - tested against jQuery 1.4.x
*/
(function($){  
	$.fn.pageScroller = function(options) {  
		var defaults = {  
			duration: 750,
			appendFragment: true,
			scrollTarget: 'html,body'
		};  
		var options = $.extend(defaults, options);  

		return this.click(function(event) {
				event.stopPropagation();
				event.preventDefault();
				var fragment = $(this).attr('href').match(/#(.+)/)[1];
				if(options.scrollTarget != 'html,body') {
					$('html,body').animate({scrollTop: $(options.scrollTarget).offset().top}, options.duration);
				}
				$(options.scrollTarget).animate({scrollTop: $($('#'+fragment+',a[name='+fragment+']').get(0)).offset().top}, options.duration,function() {
					if(options.appendFragment) {
						window.location.hash = fragment;
					}
				});
		});
	};  
})(jQuery);